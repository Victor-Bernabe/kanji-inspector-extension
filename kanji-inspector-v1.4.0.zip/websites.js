const websites = {
  'https://jisho.org/search/': 'Jisho',
  'https://app.kanjialive.com/search/': 'Kanji alive',
  'https://thekanjimap.com/index.html?k=': 'The Kanji Map',
  'https://www.kanshudo.com/kanji/': 'Kanshudo',
  'https://translate.google.com/#view=home&op=translate&sl=ja&tl=en&text=':
    'Google Translate',
  'https://kai.kanjiapi.dev/#!/': 'Kanjikai',
  'https://kanji-inspector.victorbp.site/home/': 'Kanji Inspector'
};
