const websites = {
  'https://jisho.org/search/': 'Jisho',
  'https://app.kanjialive.com/search/': 'Kanji alive',
  'https://thekanjimap.com/index.html?k=': 'The Kanji Map',
  'https://www.kanshudo.com/kanji/': 'Kanshudo'
};
